/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package extrato;

import java.io.File;
import java.io.IOException;
import java.io.PrintStream;

/**
 *
 * @author Thiago
 */
public class HelperClass {
    
    // printa separadores --------- na tela, para o output
    public static void printSeparador(){
        System.out.println("----------------------------------------");
    }
    public static String ajusteEspaco(int tamanho){
        String espaco = "";
        for( int i = 0; i<tamanho; i++){
            espaco+= " ";
        }
        return espaco;
    }
    
    public static void geraTxt(File file)throws IOException{

      //Instantiating the PrintStream class
      PrintStream stream = new PrintStream(file);
      System.setOut(stream);
    }
    
}
