/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package extrato;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.*;


/**
 *
 * @author Thiago
 */
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException{
        // TODO code application logic here
        
        Scanner s = new Scanner(System.in);
        
        System.out.println("Insira o nome completo do arquivo de entrada.");
        String arquivo_entrada = s.nextLine();
        
        System.out.println("Insira o nome do arquivo de saída.");
        String arquivo_saida = s.nextLine();
        
        
        
        BufferedReader in = new BufferedReader(new FileReader("resources/" + arquivo_entrada));
        
        // dados do input
        String linha, valor, contaId, operacao;
         
        
        
        
        // index de inicio do input
        int indContaId = 0;
        int indOperacao, indValor;
        
        int operacaoInteiro, contaIdInteiro;
        int valorRacional;
        
        ListaEncadeada<Extrato> listaExtrato = new ListaEncadeada();        

        
        Extrato e;
        Valores v;
        
        
        
        while ((linha = in.readLine())!=null){

            e = new Extrato();
            v = new Valores();

            // define o inicio de cada variavel na linha
            indOperacao = linha.indexOf(",") + 1;
            indValor = linha.indexOf(",", indOperacao) + 1;
            
            // atribui as variaveis as entradas
            contaId = linha.substring(indContaId, (indOperacao - 1));
            operacao = linha.substring(indOperacao, (indValor - 1));
            valor = linha.substring(indValor);
            
            operacaoInteiro = Integer.parseInt(operacao);
            valorRacional = Integer.parseInt(valor);
            contaIdInteiro = Integer.parseInt(contaId);
            
            
            // setar as variaveis da iteração atual
            e.setNumero_conta(contaIdInteiro);
            v.setOperacao(operacaoInteiro);
            v.setValor(valorRacional);
            
            // verifica se o id da conta ja foi inserido
            if(!listaExtrato.contem(e)){
                e.getValores().inserir(v);
                listaExtrato.inserir(e);
            }else{ // se ja, insere em Valores dessa conta
                for (Extrato extratoItera : listaExtrato) {
                    if(e.equals(extratoItera)){
                        extratoItera.getValores().inserir(v);
                    }        
                }
            }     
        }
        
        File arquivo = new File("resources/" + arquivo_saida);
        
        String ajusteEspaco = "";
        String ajusteEspaco2 = "";
        HelperClass.geraTxt(arquivo);
        for (Extrato e1 : listaExtrato) {
            
            System.out.println("Número da conta: " + e1.getNumero_conta());
            HelperClass.printSeparador();
            System.out.println("Detalhes das Transações:");
            HelperClass.printSeparador();
            int saldo = 0;
            System.out.println("Tipo          | Valor  | Saldo");
            HelperClass.printSeparador();
            for (Valores v1 : e1.getValores()) {
                int tipo = v1.getOperacao();
                int quantidade = v1.getValor();
                if(tipo == 1 || tipo == 4){
                    saldo -= quantidade;
                }else if(tipo == 2){
                    saldo += quantidade;
                }
                String strOp = "";
                
                if(tipo == 1){
                    strOp = "Saque";
                    ajusteEspaco=HelperClass.ajusteEspaco(9);
                }else if(tipo == 2){
                    strOp = "Depósito";
                    ajusteEspaco=HelperClass.ajusteEspaco(6);
                }else if(tipo == 4){
                    strOp = "Pagamento";
                    ajusteEspaco=HelperClass.ajusteEspaco(5);
                }
                ajusteEspaco2=HelperClass.ajusteEspaco(7-((Integer.toString(quantidade)).length()));
                System.out.printf("%s%s| %d%s| %d\n", strOp,ajusteEspaco,quantidade,ajusteEspaco2, saldo);   
            }
            HelperClass.printSeparador();
            System.out.println("Saldo Atual: " + saldo);
            System.out.println("");
        }
    }
}
