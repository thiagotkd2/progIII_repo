/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package extrato;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 *
 * @author Thiago
 * @param <T>
 */


public class ListaEncadeada<T> implements Iterable<T>{
    
    private Nodo<T> cabeca;

    public ListaEncadeada(){
        cabeca = null;
    }

    public boolean contem(T dado){
        return buscar(dado) != null;
    }
    
    private Nodo<T> buscar(T dado){
        Nodo<T> aux = cabeca;
        while(aux != null){
            if(aux.dado.equals(dado)){
                return aux;
            }
            aux = aux.prox;
        }
        
        
        return null;
    }

    public Nodo<T> getCabeca() {
        return cabeca;
    }
    
    public void inserir(T dado){
        Nodo<T> nodo = new Nodo<>(dado);
        inserir(nodo);
    }
    
    private void inserir(Nodo nodo){
        if (cabeca == null){
            Nodo cabecaAtual = cabeca;
            cabeca = nodo;
            nodo.prox = cabecaAtual;
        }else{
            Nodo ultimoAtual = acharUltimo();
            ultimoAtual.prox = nodo;
            nodo.prox = null;
        }
    }
    
    public Nodo<T> acharUltimo(){
        Nodo ultimo = cabeca;
        while(ultimo.prox != null){
            ultimo = ultimo.prox;
        }
        return ultimo;
    }
    
    public void remover(T dado){
        Nodo<T> nodo = buscar(dado);
        remover(nodo);

    }

    private void remover(Nodo nodo){
        if(cabeca == null) throw new IllegalStateException("underflow");
        
        if (nodo == cabeca){
            cabeca = cabeca.prox;
            return;
        }
        
        // procura o no anterior
        Nodo ant = cabeca;
        while(ant.prox != null && ant.prox != nodo){
            ant = ant.prox;
        }
        
        
        if (ant.prox != nodo) throw new IllegalStateException("nodo nao existe");
        
        ant.prox = nodo.prox;
        nodo.prox = null;
        
    }

    class Nodo<T> {
        T dado;
        Nodo<T> prox;

        public Nodo (T dado){
            this.dado = dado;
            this.prox = null;
        }
        
        public T getDado() {
            return dado;
        }
    }

    @Override
    public Iterator<T> iterator(){
        return new Iterator<T>(){
            Nodo<T> atual = cabeca;

            @Override
            public boolean hasNext(){
                return atual != null;
            }

            @Override
            public T next(){
                if(!hasNext()) throw new NoSuchElementException();
                T result = atual.dado;
                atual = atual.prox;
                return result;
            }
        };
    }
}
