/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package extrato;

import java.util.Objects;

/**
 *
 * @author Thiago
 */
public class Extrato {

    private int numero_conta;
    private ListaEncadeada<Valores> valores;
    
    public Extrato(){
        valores = new ListaEncadeada();
    }

    public void setNumero_conta(int numero_conta) {
        this.numero_conta = numero_conta;
    }

    public void setValores(ListaEncadeada valores) {
        this.valores = valores;
    }

    public int getNumero_conta() {
        return numero_conta;
    }

    public ListaEncadeada<Valores> getValores() {
        return valores;
    }


    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Extrato other = (Extrato) obj;
        return this.numero_conta == other.numero_conta;
    } 
}